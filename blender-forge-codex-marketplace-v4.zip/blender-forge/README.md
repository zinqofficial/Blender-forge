# Blender Forge v4

A Codex marketplace plugin for creating substantially better Blender assets: characters, environments/maps, props, PBR materials and game-ready exports.

Unlike a generic “make a 3D model” instruction, Blender Forge routes work through specialist skills and requires visual QA/revision before an asset is considered complete.

## Install from a GitHub repo
Once this folder is pushed as a repository:

```bash
codex plugin marketplace add <YOUR_GITHUB>/<YOUR_REPO>
codex plugin add blender-forge@blender-forge-marketplace
```

You can also open `/plugins` in Codex and install it from the added marketplace.

## Example requests

- “Build a realistic abandoned UK shopping centre environment for Unreal, modular and game-ready.”
- “Create a realistic heavyweight wrestler base character from these front/side references, ready to rig.”
- “Model this exact desk from my reference images and export FBX with 2K PBR textures.”
- “Take this existing Blender character and fix its topology, materials and proportions so it looks AAA-quality.”

## Skills
- `model-anything`: intake, planning, routing and end-to-end production loop
- `character-artist`: anatomy, likeness, clothing, hair and deformation readiness
- `environment-artist`: maps, buildings, modular kits, set dressing and gameplay scale
- `prop-artist`: hard-surface and organic props
- `materials-texturing`: UVs, PBR, baking and material quality
- `game-ready-optimizer`: topology, LODs, collisions, pivots and export
- `quality-review`: render-based critique and revision gate

## v3: Forge Loop
Blender Forge combines target-driven visual iteration with measured, anchor-based modeling and semantic spatial QA. High-quality scenes are built, captured, criticized, repaired and re-checked rather than accepted after a one-shot generation pass. Environment placement uses explicit contracts for orientation, support, containment, clearance, traversal and repeated-system boundaries.


## v4 highlights
- Consistent multi-angle reference packs and matching Blender QA cameras
- Approved-reference-is-target contract
- Persistent scene manifest and completeness sweep
- World -> Zone -> Structure -> Object -> Detail hierarchy
- Macro blockout gate before expensive detail
- Root-cause repair instead of descendant patching
- Controlled semantic variation for repeated content
- Interaction-aware game asset authoring and metadata
- Instance-friendly large scenes
- Time estimates for substantial jobs and deterministic-script preference
- PASS/WARN/FAIL multi-camera QA
