# Spatial Contracts and Deterministic Placement

Every functional/repeated object class should have a placement contract before mass placement.

Suggested fields:
- class / semantic role
- anchor or parent zone
- allowed surfaces / volume
- forbidden volumes
- orientation rule / focal target
- support rule
- spacing / row pitch
- minimum clearance
- overlap policy
- boundary policy
- accessibility requirement
- generator/source object
- validation views/tests

## Arena example

### Audience seat
Anchor: seating section / row curve.
Allowed: seat platform only.
Forbidden: aisles, stairs, railings, walls, barricade clearance, portals/exits.
Orientation: face ring focal point, or blended ring/stage target for intentionally angled sections; maintain coherent row orientation.
Support: all legs/base plausibly meet seating platform.
Spacing: deterministic row/seat pitch; no overlapping seat envelopes.
Boundary: reject instances crossing section polygon; do not squeeze malformed edge seats into gaps.
Validation: center row, first/last seat, curved transition, aisle boundary, top/bottom row.

### Barricade
Anchor: ringside perimeter path.
Orientation: tangent to perimeter, audience face outward/ringside face inward as designed.
Continuity: coherent segments; only intentional openings.
Clearance: preserve ring working zone, ramp connection, production/camera positions and required gates.

### Entrance ramp
Anchors: stage exit and ringside destination.
Contract: continuous walkable path, sensible grade, adequate width/headroom, no prop/seating penetration, intentional barricade openings.

### Screen
Anchor: stage/truss/architecture.
Orientation: display normal points toward intended viewing zone. Verify sightline from representative audience/player cameras.

### Truss/light
Support: truss structurally anchored/suspended plausibly; lights attach to truss, not nearby air.
Clearance: no roof/screen penetration.
Aim: fixtures have an intentional target or lighting role.

## Validation algorithms
Use deterministic checks where practical:
- AABB broad-phase then BVH/narrow-phase intersection for suspicious pairs.
- Raycast downward for support/floating checks.
- Dot product between object forward vector and normalized target direction for orientation checks.
- Point-in-zone / boundary checks for containment.
- Clearance proxy volumes for aisles, doors, stairs, ramp and gameplay paths.
- Duplicate transform/proximity checks for accidental stacked instances.
- Slope/step/rise checks for traversable stairs/ramps when dimensions are known.

Automated checks generate candidates; visual inspection decides ambiguous cases.
