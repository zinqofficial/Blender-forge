---
name: environment-artist
description: Build game environments, maps, rooms, buildings, streets, arenas and modular environment kits in Blender with believable scale, functional spatial logic, correct object placement and optimization.
---
# Environment Artist

An environment is a functioning place, not a collection of meshes. Every placed object must make spatial and semantic sense.

## 1. Start with purpose, gameplay and scale
Define units and create a human scale reference. Identify the scene's focal points, traversal routes, restricted zones, entrances/exits, vertical connections, audience/player areas and camera-critical views before decoration.

For every environment, make a simple zone plan before detailed modeling. Zones may include walkable floor, seating, stage/performance, service/backstage, roads, sidewalks, rooms, aisles, exits, inaccessible structure and prop/set-dressing zones.

Do not decorate until the blockout proves that people can plausibly use the space.

## 2. Break the scene into systems
- structural shell / terrain
- gameplay and circulation zones
- modular architecture kit
- hero landmarks / focal targets
- repeated systems such as seats, shelves, lights or barriers
- reusable props
- trim/decal/material families
- foliage/natural elements
- set dressing/storytelling
- collision and LOD/HLOD strategy

Large maps must not be one giant unique mesh unless there is a compelling technical reason.

## 3. Semantic placement rules
For substantial scenes, also read `references/spatial-contracts.md`. Treat placement contracts as executable design constraints, not suggestions.
Before mass-placing an object class, define its placement contract:
- allowed zone/surface
- forbidden zones
- minimum clearance from walls and other objects
- expected orientation or focal target
- spacing between instances
- floor/support requirement
- whether overlap is ever allowed
- accessibility/circulation requirements

Examples:
- audience chairs face the performance focal point or follow the seating-row tangent; never use arbitrary world rotation
- desks/chairs remain usable and are not pushed through walls
- wall props attach to a valid wall surface rather than float nearby
- ceiling lights attach to ceiling/truss and aim where lighting is useful
- doors retain opening clearance
- stairs connect two reachable elevations
- props sit on a supporting surface unless intentionally suspended
- barriers form coherent boundaries without blocking required entrances

For procedural/instanced placement, orientation must derive from scene geometry, row direction, path direction, surface normal or an explicit target. Random rotation is allowed only for objects where random orientation is physically believable.

## 4. Collision, containment and support validation
After every major placement pass, validate the scene instead of waiting until the end.

Reject or repair objects that:
- intersect walls, floors, ceilings, barriers or unrelated props beyond a tiny intentional tolerance
- are embedded in geometry
- visibly float above their intended support
- extend outside their assigned room/zone
- block doors, aisles, stairs, exits or gameplay paths
- create impossible gaps or inaccessible spaces
- are duplicated in effectively the same location
- have obviously wrong scale, orientation or vertical alignment

Use bounding boxes/BVH/raycast tests or other Blender geometry checks when practical, then visually inspect. Automated collision checks do not replace visual review.

## 5. Architecture
Use plausible dimensions and construction logic. Walls have thickness where visible. Doors/windows align with structure. Stairs are traversable and terminate correctly. Railings protect believable edges. Roofs, gutters, frames, trims and service elements should make physical sense for the chosen place/era.

Avoid geometry that merely looks architectural from one camera. Inspect corners, wall junctions, door frames, floor transitions, stair landings and exterior/interior joins.

## 6. Repeated layouts and seating
Repeated assets require deterministic layout logic plus variation, not uncontrolled scatter.

For seating:
- define sections, rows, aisles and focal target(s)
- orient each seat using the row/focal geometry
- keep consistent row pitch and useful legroom
- preserve aisles and access routes
- prevent seats from crossing walls, railings, stairs or section boundaries
- handle curved/angled sections intentionally
- inspect edge seats and transitions between sections because these fail most often

Do not place hundreds of objects and assume the array/Geometry Nodes result is valid. Sample-check interiors, edges, corners and transitions.

## 7. Wrestling / sports arena specialization
When the request is a wrestling arena or similar indoor sports venue, explicitly plan and validate:
- ring/field/court as the primary spatial anchor
- ringside safety/working clearance
- barricade perimeter and intentional openings
- announce/timekeeper/production positions if requested
- entrance ramp/path from stage to ring with uninterrupted traversal
- stage, tunnels, screens and set pieces with believable support
- floor seating sections and clear aisles
- tiered seating/bowl orientation toward the ring and/or stage as appropriate
- stairs, vomitories, concourses and exits where visible/relevant
- camera/production sightlines if the scene is for a wrestling game
- lighting truss/rigging above appropriate targets, not clipping the roof or screens
- speaker/screens facing useful audience directions
- backstage/service access where required

Arena hard failures include: chairs facing away from the ring without a design reason; seats intersecting barricades/walls; ramp blocked by props; ring or stage off-scale; truss intersecting architecture; inaccessible aisles; floating crowd props; repeated sections visibly penetrating each other; screens facing unusable directions; or major sightlines blocked accidentally.

## 8. Natural environments
Build macro terrain first, then erosion/large breakup, then vegetation distribution, then close-detail zones. Avoid uniform procedural scatter. Use ecological and human-use logic to create clusters, paths, clearings and variation. Keep paths and gameplay spaces readable.

## 9. Set dressing
Every prop should support navigation, story, scale, composition or material breakup. Avoid filling empty space with unrelated clutter. Use controlled repetition with variation.

Use density zones: hero areas can carry more authored detail; background zones should be cheaper and simpler. Clutter must not destroy traversal or visual hierarchy.

## 10. Environment QA gate
Review at minimum:
- overhead plan view
- player/human eye level along major routes
- focal-point view(s)
- each major seating/prop section
- corners and boundaries
- entrances/exits and stairs
- close views of procedural transition areas

Check scale, clipping, floating props, support, orientation, containment, blocked paths, inaccessible gaps, obvious tiling, accidental repeated rotations, z-fighting, sightline problems and nonsensical object relationships.

If a defect pattern appears in a repeated system, fix the generator/layout rule and regenerate rather than manually hiding a few bad instances.

The environment cannot pass merely because it looks good in one beauty render.

## v4 large-scene reliability requirements
For large environments, use the multi-angle reference pack and scene manifest from `../model-anything/references/`. Do not detail a scene whose macro layout has not passed. Create purpose-driven QA cameras matching the approved target views and re-capture them after major stages.

Organize work as `World -> Zone -> Structure -> Object -> Detail`. Treat repeated systems (seating, lights, façade bays, shelving, crowd furniture) as generators/instance families. If they fail, repair the generator or governing anchors instead of hand-patching descendants.

Variation must be semantic: derive density, graphics, wear, prop selection and orientation from zone/function. Random clutter or logo repetition is not acceptable visual richness.

For game environments preserve future interactive/breakable/movable objects separately and tag their intended behavior. Repeated static objects should be instance-friendly. Run a completeness sweep before final QA so missing concourses, service areas, roof structure, access paths, hero dressing or other target-required zones cannot silently pass.
