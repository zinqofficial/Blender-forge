---
name: quality-review
description: Mandatory final visual, spatial and technical QA for Blender Forge assets. Render multiple views, test placement/collisions, critique defects, revise, and only then approve export.
---
# Quality Review

This is a gate, not a compliment generator. Successful script execution is not proof of quality.

## Render evidence
Create clear review renders/screenshots: front, back, left/right or useful 3/4 angles; close-ups of important areas; wireframe/topology view when topology matters; UV view when texturing matters; deformation pose for rigged characters.

For environments additionally capture overhead/plan view, several player-eye views, major entrances/routes, focal areas, corners/boundaries and representative repeated-layout sections.

## Score 0-5
Score:
- silhouette/proportions
- reference/design fidelity
- construction/anatomy believability
- topology/shading
- materials/textures
- detail hierarchy
- technical/game readiness
- consistency from all angles
- spatial logic / object placement for environments
- traversal / accessibility for playable environments

Any applicable category below 4 requires revision unless the user explicitly requested a rough prototype.

## Detect common AI/automation failures
Look specifically for: melted forms, random grooves, impossible joins, over-rounded edges, noisy detail everywhere, generic faces, accidental asymmetry, floating/intersecting parts, stretched UVs, fake material variation, overused grunge, identical repeated props, broken normals, razor edges, excessive subdivision and good-front/bad-back modeling.

For environments also hunt for:
- chairs/props facing nonsensical directions
- objects embedded in walls/floors/ceilings
- floating objects without support
- blocked doors, aisles, stairs or exits
- duplicate objects occupying the same space
- props outside their intended room/zone
- bad array/Geometry Nodes edge cases
- stairs/ramps that lead nowhere or miss their destination
- barriers with accidental gaps or impossible overlaps
- lights/screens/speakers aimed somewhere useless
- obvious scale mismatches
- inaccessible areas caused by set dressing
- major unintended sightline obstruction

## Spatial QA for environments
Do not rely on a beauty render. Perform a dedicated spatial pass:
1. Inspect overhead layout and zone boundaries.
2. Inspect collision/intersection candidates with Blender geometry tests when available.
3. Check support using raycasts/vertical relationships where practical.
4. Check orientation of directional object classes against their expected target/path/row.
5. Check required clearance volumes around doors, stairs, aisles and traversal routes.
6. Inspect procedural-system edges, corners and transitions.
7. Walk/view the scene from human/player height.

A small intentional contact/penetration required for construction is acceptable; visible or function-breaking clipping is not.

## Repeated-system rule
When multiple failures share one cause, do not patch instances individually. Fix the source rule, modifier, Geometry Nodes network, script, array or placement algorithm and regenerate. Then re-check a sample from the center, edges, corners and transitions.

## Target-driven critic loop
When a target/reference exists, compare the current evidence directly against it. Evaluate composition, proportions, silhouette, spatial density, materials, lighting, recognizable landmarks and detail hierarchy. Do not optimize only for pixel similarity: target similarity cannot excuse impossible geometry, wrong-facing functional objects, clipping, blocked traversal or technical failures.

Maintain two independent gates:
- VISUAL GATE: does it convincingly approach the requested/reference result?
- REALITY/FUNCTION GATE: is the scene physically, semantically and technically coherent?
Both must pass.

## Revision loop
List the three highest-impact defects. Fix causes rather than isolated symptoms. Re-render/re-check the affected views. For high-quality scenes perform at least three meaningful build/critic/repair passes unless all gates already pass with strong evidence. Repeat further when major defects remain or until a real blocker is reached.

Never approve an environment while known placement, traversal, clipping or orientation errors remain simply because correcting them would take longer.

## v4 reference-camera and completeness gate
For exact-match or complex scenes, review every important locked reference camera independently. Use PASS / WARN / FAIL per view and per category; do not average a critical failure into an overall pass. Compare silhouette, anchors, depth/layout, material/value structure, interfaces/contacts, semantic placement and completeness.

Before PASS, run the scene-manifest completeness sweep. Explicitly identify the single largest remaining discrepancy, trace it to its causal generator/structure, repair it, and re-render affected cameras. A tool/API success, clean render, or attractive hero angle cannot override a failed side/rear/high view or missing required zone.
