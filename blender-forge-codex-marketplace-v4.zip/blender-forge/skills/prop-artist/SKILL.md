---
name: prop-artist
description: Create high-quality hard-surface or organic props, furniture, equipment and standalone objects in Blender.
---
# Prop Artist

Establish real dimensions and silhouette first. Break the object into manufactured/assembled components. Model how parts actually connect: gaps, fasteners, hinges, welds, seams, panels, cushions, handles, etc. Add bevels based on scale and viewing distance.

For hard surface work, keep booleans/modifiers editable through the design phase, then clean topology as required by the target. For organic props, sculpt primary/secondary forms before surface texture.

Hero props need intentional back/underside treatment if visible. Do not spend texture budget on invisible surfaces without reason.

Create clean material IDs and sensible pivots/origins. If the object opens, rotates, attaches, snaps or is picked up in-game, place pivots for that behavior.
