---
name: game-ready-optimizer
description: Make Blender assets game-ready with sane topology, LODs, collision, pivots, naming, transforms and engine export.
---
# Game-Ready Optimizer

Target quality to screen size and platform instead of chasing arbitrary polygon counts.

## Geometry checks
Remove accidental internal/duplicate geometry, non-manifold defects where inappropriate, zero-area faces and unseen excess detail. Preserve silhouette. Triangulate deterministically when the destination requires it and inspect shading afterward.

## LODs
For assets that need LODs, reduce small silhouette-neutral features first. Maintain UV/material compatibility where useful. Verify each LOD visually at expected transition distance.

## Collision
Use simple primitives/convex hulls for ordinary props and architecture where possible. Complex collision is reserved for shapes/gameplay that require it. Name collision meshes according to destination engine conventions when known.

## Export hygiene
Apply/record scale and transforms correctly; check axis/up convention; origin/pivot; object/bone names; material slots; animation ranges; smoothing/normals; texture paths. Export FBX/glTF/USD/etc according to target requirements.

## Report
Record source scale, dimensions, vertices/triangles, material count, texture resolutions, LODs, collision type, rig/bones if present, and export settings.

## v4 interaction and instance preservation
Optimization must not erase gameplay intent. Before merging, inspect interaction metadata/manifest. Keep movable, animated, breakable, screen, collision-critical and hero-interaction parts separately addressable. Prefer instance-ready repeated families for large repetition such as arena seats. Record intended engine handling (static/instance/interactive/breakable) in the asset report.
