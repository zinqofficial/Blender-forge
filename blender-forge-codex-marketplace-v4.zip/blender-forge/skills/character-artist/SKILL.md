---
name: character-artist
description: Create or improve human, humanoid, creature, clothing and hair assets in Blender with strong proportions, anatomy, likeness and animation-ready construction.
---
# Character Artist

## Priorities
1. silhouette and body proportions
2. head/face likeness or intentional design language
3. anatomy and joint landmarks
4. clothing construction and layering
5. hair/groom silhouette
6. skin/material response
7. deformation-ready topology
8. tertiary detail

A detailed character with weak proportions is a failed character.

## Base workflow
Start from a suitable clean base mesh when available rather than rebuilding generic anatomy from cubes. For original work, establish height and body landmarks first. For likeness, use front + side + 3/4 references when available and compare repeatedly.

Use sculpting for organic forms, then retopologize where necessary. Preserve loops around eyes, mouth, shoulders, elbows, wrists, hips, knees and ankles. Keep density proportional to deformation and camera importance.

## Face
Check cranial mass, jaw/chin, brow, eye spacing/depth, nose projection/width, mouth width/volume, ear placement and neck transition. Do not over-smooth faces into a generic AI-like person. Asymmetry may be retained when reference-supported.

## Clothing
Clothes are garments, not body paint. Give hems, seams, thickness, folds driven by gravity/tension/compression, and correct layering. Avoid random wrinkle noise. Separate garments where it improves simulation, editing or materials.

## Hair
Prioritize hairline and large clumps/cards/curves before flyaways. For games, choose hair cards/curves/mesh strategy appropriate to target engine and performance. Avoid solid helmet hair unless stylistically intended.

## Rig readiness
Before rigging: transforms sane, symmetry decisions finalized, topology supports deformation, intersections controlled. Test extreme shoulder/hip/knee/elbow poses if a rig exists. Correct collapsing volume and bad weighting rather than hiding it.

## Character QA
Render neutral front, side, back and 3/4 views plus a close face view. For animated characters, include at least one deformation test pose. Compare against references at matching perspective/focal length where practical.
