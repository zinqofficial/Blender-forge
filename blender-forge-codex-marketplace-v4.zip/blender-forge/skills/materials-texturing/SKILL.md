---
name: materials-texturing
description: UV unwrap, bake and create physically plausible PBR materials and textures for Blender/game assets.
---
# Materials & Texturing

## UVs
Use intentional seams, low distortion, adequate padding and consistent texel density. Stack/mirror only when acceptable for the asset. Reserve more density for faces, hero areas, decals or close-up surfaces as appropriate.

## PBR
Use base color, roughness and normal as the core. Add metallic, AO, opacity, emissive, height or masks only when useful. Metallic is generally binary by material region, not decorative grey noise. Roughness carries much of realism: vary it according to material, touch, wear, grease, moisture and age.

## Material logic
Separate materials by physical substance, not arbitrary colors. Wood grain follows growth/cut direction. Scratches follow contact. Edge wear appears where contact would occur. Dirt accumulates in plausible recesses and exposed environmental zones. Avoid universal grunge overlays.

## Baking
For high-to-low workflows, verify cage/ray distances, hard edges vs UV seams, tangent basis and normal orientation. Inspect baked maps for skew, projection leaks and gradients before moving on.

## Presentation
Evaluate materials under at least one neutral HDRI/studio setup and one harsher grazing-light setup. A material that only looks good under one dramatic light has not been adequately checked.
