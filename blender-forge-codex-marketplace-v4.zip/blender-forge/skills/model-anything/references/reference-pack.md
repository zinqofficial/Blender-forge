# Multi-Angle Reference Pack Protocol

Use this protocol when a single reference cannot constrain the asset reliably, especially environments, architecture, vehicles, complex props and exact reconstruction.

## Purpose
Prevent the common failure where one camera looks correct while unseen sides, depth, proportions or layout drift away from the approved design.

## 1. Lock the design
Identify the approved target and write a short immutable design contract: silhouette, dimensions/anchors, major structures, material language, signature details and prohibited changes. If Forge itself generated an image that the user approved, that approved image is a target, not loose inspiration.

## 2. Establish views
Use supplied views when available. If the workflow can generate reference imagery, create additional views BEFORE detailed modeling. Prefer a coherent set such as:
- HERO: approved primary view
- FRONT / principal elevation
- REAR / opposite direction
- LEFT 3/4
- RIGHT 3/4
- HIGH / plan-like overview
- DETAIL views for critical interfaces or hero features

Not every asset needs every view. Use enough to constrain hidden geometry.

## 3. Consistency gate
Every view must represent the same object/scene. Compare landmarks across views: dimensions, openings, floor count, stage/ring placement, roofline, structural bays, color/material boundaries, repeated elements and hero features. If views conflict, do not average them silently. Preserve the approved primary target and resolve uncertainty conservatively; document the assumption.

## 4. Blender camera matching
Create named cameras corresponding to important references, e.g. `REF_Hero`, `REF_Rear`, `REF_Left34`, `REF_Right34`, `REF_High`. Match focal length/perspective and framing approximately enough that overlay/comparison is meaningful. Lock or protect them from accidental edits.

## 5. Anchor measurements
Derive stable anchors before detail: overall width/depth/height, key centerlines, floor/elevation heights, doorway/stair widths, ring/stage/ramp dimensions, wheelbase, human scale or other domain anchors. Record them in the scene manifest/report.

## 6. Review cadence
Render/capture the reference cameras after blockout, after primary forms, after material/lighting pass and at final QA. Compare each view independently. Fix the largest structural mismatch at its generator/root cause rather than patching many descendants.

## 7. PASS criteria
PASS only when no important view reveals a major contradiction, missing structure, wrong silhouette, broken depth relationship, inaccessible functional area or inconsistent design.
