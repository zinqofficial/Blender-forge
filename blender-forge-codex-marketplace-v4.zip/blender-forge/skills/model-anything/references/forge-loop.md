# Forge Loop — Target-Driven Build / Critic / Repair

Use this loop for any quality-sensitive asset or scene, especially environments, characters, hero props, and user requests such as "good", "realistic", "AAA", "production quality", "match this", or "doesn't look AI".

## 1. Lock the target
Use user references as the primary contract. If there is no image reference and image generation is available, create a realistic target render/reference frame representing an achievable Blender/game result, not vague concept art. For environments, one beauty target is insufficient: establish at least a hero/focal view plus a plan/layout target or written spatial contract.

Record the target's major measurable facts: dimensions/ratios, part count, landmarks, focal hierarchy, materials, camera, lighting, repeated systems, and functional relationships.

Never let a generated target override explicit user requirements or physical/gameplay correctness.

## 2. Construction pass
Build from coarse to fine. Use anchors and dimensions rather than eyeballing important placement. Establish primary anchors first (origin, floor, human scale, major focal object, boundaries, key heights). Derive dependent placement from those anchors.

For repeated structures, build and validate one module, then duplicate/instance with measured spacing or a deterministic generator. Do not hand-place hundreds of nearly identical pieces.

## 3. Interface/contact pass
Before visual polish, inspect where parts meet: floor/wall, wall/ceiling, stair/landing, beam/post, clothing/body, wheel/axle, chair/floor, barricade/segment, ramp/stage, truss/support. Check gaps, penetrations, support, thickness, alignment, normals and plausible construction.

## 4. Evidence capture
Capture current renders/screenshots from views that expose errors, not only flattering views. Environments require plan/overhead and player-eye evidence. Repeated systems require center + edge + corner/transition samples.

## 5. Critic pass
Compare current evidence against both:
A. visual target/reference; and
B. semantic/technical contracts.

Critique the result as if rejecting work from another artist. Identify the highest-impact mismatches. A visually closer result must still fail if it introduces clipping, impossible construction, blocked traversal, bad topology, incorrect orientation or other semantic errors.

## 6. Repair pass
Repair causes, not screenshots. If many objects share a defect, fix the source module, anchor math, generator, Geometry Nodes graph, modifier, material or script and regenerate. Prioritize: structure/proportion -> spatial correctness -> silhouette -> materials/lighting -> secondary detail -> tertiary polish.

## 7. Repeat
Re-capture affected evidence and repeat critic/repair until applicable quality-review categories pass. Default to at least 3 meaningful passes for a high-quality scene unless it passes earlier with strong evidence. Continue beyond 3 when major defects remain and budget permits.

## Exit criteria
Do not exit because Blender commands succeeded. Exit only when the quality gate passes, requested deliverables exist, and known critical defects are resolved or explicitly reported as blockers.
