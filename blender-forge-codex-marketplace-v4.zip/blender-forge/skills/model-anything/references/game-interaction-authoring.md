# Game Interaction-Aware Authoring

Do not force every scene object into the same export treatment.

Suggested tiers:
- Tier 0 Static architecture: walls, slabs, fixed structural shell. Merge/modularize where beneficial.
- Tier 1 Animated/simple interaction: doors, drawers, gates, screens. Preserve pivot and separate mesh.
- Tier 2 Movable physics prop: chairs, bins, small tables, cases. Separate mesh, simple collision, believable origin/mass scale.
- Tier 3 Physics + contextual interaction: wrestling tables, ladders, barricades, ring components. Preserve logical sub-parts and interaction anchors.
- Tier 4 Complex interactive assembly: lockers, vehicles, multi-part machinery. Preserve hierarchy and constraints/pivots.
- Tier 5 Hero/destruction asset: bespoke fracture/logical break pieces, replacement states and high-value interaction surfaces.

When useful record custom metadata: `AssetType`, `Mobility`, `Interactive`, `MergeOnExport`, `Collision`, `InstanceGroup`, `PivotIntent`, `Breakable`, `ScreenSurface`.

Repeated static objects such as arena seats should normally be authored for instancing rather than exported as thousands of unique actors. Preserve instance identity/families and controlled variation.
