# Scene Manifest and Completeness Contract

For substantial scenes create a lightweight persistent manifest (Markdown/JSON/custom properties are all acceptable). Its purpose is to prevent forgotten zones and expensive late rebuilds.

Track at minimum:
- World / zone / structure / object name
- required vs optional
- status: TODO / BLOCKOUT / BUILT / QA / PASS / WARN / FAIL
- reference view(s) that constrain it
- dimensions/anchors where important
- material status
- gameplay intent: Static / Animated / Physics / Breakable / Screen / Interactive
- export intent: Merge / Separate / Instance
- collision/pivot requirements
- blocker/notes

## Hierarchy
Use `World -> Zone -> Structure -> Object -> Detail`. Repair at the highest causal level. If an entire seating bowl is mis-sized, fix its generator/zone dimensions rather than manually moving hundreds of seats.

## Macro gate
Before secondary detail, verify all required zones exist and major proportions/layout/traversal are plausible from reference cameras. A failed macro gate blocks expensive polish.

## Completeness sweep
Before final approval explicitly ask:
- What target feature is missing?
- What remains a placeholder?
- What was accidentally duplicated?
- What is floating/intersecting/unsupported?
- What blocks a door, stair, corridor, sightline or gameplay path?
- What hero area is visibly under-detailed compared with the target?
- What future interactive object was accidentally merged?

Any major answer becomes a repair task before PASS.
