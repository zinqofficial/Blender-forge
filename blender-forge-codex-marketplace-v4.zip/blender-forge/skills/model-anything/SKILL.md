---
name: model-anything
description: Main Blender Forge workflow. Use for any request to create, recreate, improve, texture, rig, optimize, or export a 3D model, character, prop, building, environment, or game map.
---
# Model Anything

Goal: produce a convincing, technically usable asset rather than a fast collection of primitives.

## 1. Understand the target
Extract: asset type; intended engine/use; realism/stylization; reference images; required dimensions; camera distance; animation needs; texture resolution; poly budget; export format; deadline/quality priority.

If information is missing, infer only what is low-risk and write assumptions into the report. Do not block obvious work waiting for minor preferences.

## 2. Lock the reference contract and build a reference pack
For simple assets a small reference set may be enough. For large/complex/exact-match work, read `references/reference-pack.md`. Establish multiple mutually consistent views and matching Blender QA cameras before expensive detail. If the user approved a generated concept, treat it as the target unless explicitly told otherwise.

## 3. Build a reference sheet in your reasoning
For each supplied reference identify:
- primary silhouette and proportions
- major forms and negative spaces
- construction/material boundaries
- signature features that make the subject recognizable
- roughness/metalness/transmission/emission behavior
- wear/damage/dirt logic
- likely unseen construction; keep invented areas conservative

For a real person or exact object, prioritize likeness/proportion over added detail.

## 4. Route to specialists
- Human/humanoid/creature: read `../character-artist/SKILL.md`.
- Building/room/street/landscape/map: read `../environment-artist/SKILL.md`.
- Object/weapon/furniture/vehicle component/misc asset: read `../prop-artist/SKILL.md`.
- Any textured deliverable: read `../materials-texturing/SKILL.md`.
- Any game asset: read `../game-ready-optimizer/SKILL.md`.
- Every finished asset: read `../quality-review/SKILL.md` before declaring completion.

## 5. Mandatory Forge Loop
For quality-sensitive work, read `references/forge-loop.md` and use its target-driven build → evidence → critic → repair loop. Reference fidelity never overrides semantic, spatial, topology or gameplay correctness.

## 6. Production stages
Create explicit checkpoints:
A. scene setup and real-world scale
B. blockout
C. silhouette/proportion correction
D. primary forms
E. secondary forms/construction
F. topology pass
G. UV/material plan
H. texture/material pass
I. tertiary detail only where justified
J. rig/deformation prep if needed
K. optimization/export prep
L. spatial/functional QA where applicable
M. QA renders and revision
N. final export/report

Never jump from B directly to M.

## 7. Modeling principles
Use the technique that fits the object: box/poly modeling, curves, modifiers, sculpt + retopo, geometry nodes for repetition, modular kits for architecture. Apply modifiers only when appropriate for final export. Use bevels based on physical scale. Avoid razor-sharp CG edges unless the target truly has them. Avoid boolean garbage topology on deformation surfaces.

Repeated detail should be authored procedurally or instanced where sensible. Unique hero detail should be modeled deliberately, not generated as random noise.

## 8. Save recoverably
Use staged saves for substantial work (`asset_blockout.blend`, `asset_model.blend`, `asset_final.blend`) or equivalent versioning. Do not destroy the only editable source during optimization.

## 9. Scene manifest and macro gate
For substantial scenes read `references/scene-manifest.md`. Maintain `World -> Zone -> Structure -> Object -> Detail`, validate macro layout before detail, and run a final completeness sweep. For game assets with future interaction, also read `references/game-interaction-authoring.md`.

For jobs likely to exceed ~15 minutes, provide/record a time estimate before expensive work and revise it after blockout or major repairs.

## 10. Completion gate
The asset is NOT finished until quality-review passes and technical checks pass. Environments must also pass spatial/functional QA: placement, orientation, support, intersections, containment and traversal/accessibility. If the review identifies major silhouette, material, topology, scale, or presentation defects, revise automatically before presenting the result.
