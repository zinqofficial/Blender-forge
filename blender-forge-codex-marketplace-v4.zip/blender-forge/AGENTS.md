# Blender Forge v4

Blender Forge is a production-minded 3D asset agent workflow. For any create/rebuild/improve/optimize/texture/rig/export request, begin with `skills/model-anything/SKILL.md` and route to the relevant specialist.

## Core rule
REFERENCE / TARGET -> MEASURE -> PLAN -> BLOCKOUT -> VALIDATE MACRO -> BUILD -> CAPTURE -> COMPARE -> FIND LARGEST DISCREPANCY -> ROOT-CAUSE REPAIR -> RE-TEST -> GAME-READY VALIDATION.

A successful tool call is never proof that the asset is finished.

## Reference contract
- If the user supplies or approves a design/reference, treat it as the visual target unless they explicitly say it is inspiration only.
- For large/complex scenes, do not trust one beauty image. Establish a consistent multi-angle reference pack before expensive detail: hero/front, opposite/rear, left/right or 3/4 views, elevated/plan-like view, and detail views when useful.
- All generated/derived reference views must depict ONE locked design. Never quietly redesign the object between angles.
- Create Blender QA cameras that approximately reproduce the important reference viewpoints. Use those cameras throughout the build, not only at the end.
- Distinguish target references from authenticity references. Authenticity references inform believable construction; they do not override an approved target.

## Non-negotiable quality rules
- Never treat a primitive blockout as a finished model.
- Match requested visual target, genre, era, scale and game art direction.
- Work coarse-to-fine. Macro silhouette, proportions, layout and negative space must pass before expensive detail.
- Prefer believable construction over random surface noise.
- Inspect from multiple angles. A front-view success with broken sides/back is a failure.
- Check transforms, normals, topology, UVs, texel density, materials, scale, origin/pivot and naming before export.
- Characters require deformation-aware topology when intended to animate.
- Environments require modularity, scale consistency, collision/LOD strategy and playable/readable spaces.
- Environment objects must obey semantic placement rules: orientation, support, containment, clearance, accessibility and purpose. Blind random scatter is forbidden.
- Never approve known clipping, floating props, blocked traversal, inaccessible stairs/doors, or procedural placement failures.
- Do not fabricate completion. Report what was actually created and verified.

## Scene hierarchy and manifest
For substantial scenes maintain a persistent scene manifest/completeness contract. Organize conceptually as:
`World -> Zone -> Structure -> Object -> Detail`.
The manifest records required zones/objects, status, reference coverage, interaction/export intent and known blockers. Before completion run a completeness sweep: "What is required by the target but absent, placeholder, duplicated, inaccessible, or visually underdeveloped?"

## Semantic variation
Repeated content should be efficient but not visibly cloned. Use controlled variation based on function and location (materials, wear, graphics, orientation, density, prop families). Never use arbitrary noise, random logo spam, or variation that breaks the design language.

## Interaction-aware authoring
For game assets preserve separately addressable parts that may later move, animate, break, open, receive physics, change material, play video or need independent collision. When useful attach metadata such as `AssetType`, `Mobility`, `Interactive`, `MergeOnExport`, `Collision`, `InstanceGroup`, and `PivotIntent`. Do not merge away future gameplay capability merely to reduce object count.

## Time and usage discipline
For work likely to exceed ~15 minutes, estimate the build before expensive execution. Update the estimate after blockout and after major repairs. Record estimated vs actual time in the report when possible. Move deterministic/repetitive generation and audits into scripts; reserve model reasoning for visual judgment, architecture, ambiguity and root-cause repair. Do not skip QA to save calls.

## Blender access
Use available Blender MCP/tooling when present. If no direct Blender tool is available, create deterministic Blender Python (`bpy`) scripts that perform the work and save outputs. Do not merely describe clicks when asked to build.

## Default output
Keep source `.blend`, exported game asset(s), textures, reference/QA captures where useful, and `ASSET_REPORT.md` containing scale, triangle count, texture sets, materials, rig status, export settings, reference cameras, checks performed, performance/interaction notes, estimated/actual time where available, and known limitations.
