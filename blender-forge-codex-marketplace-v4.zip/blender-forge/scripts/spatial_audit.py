"""Blender Forge spatial-audit helpers.
Run inside Blender Python. These utilities flag candidates for visual review;
they do not replace semantic inspection.
"""
import bpy
from mathutils import Vector


def world_bbox(obj):
    return [obj.matrix_world @ Vector(c) for c in obj.bound_box]


def aabb(obj):
    pts = world_bbox(obj)
    return (Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts))),
            Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts))))


def aabb_overlap(a, b, tolerance=0.002):
    amin, amax = aabb(a); bmin, bmax = aabb(b)
    return all(amin[i] < bmax[i]-tolerance and amax[i] > bmin[i]+tolerance for i in range(3))


def forward_dot_to_target(obj, target, local_forward=Vector((0,-1,0))):
    forward = (obj.matrix_world.to_3x3() @ local_forward).normalized()
    direction = (target.matrix_world.translation - obj.matrix_world.translation).normalized()
    return forward.dot(direction)


def near_duplicate(a, b, position_eps=0.01, rotation_eps=0.01):
    dp = (a.matrix_world.translation-b.matrix_world.translation).length
    dr = sum(abs(x-y) for x,y in zip(a.rotation_euler,b.rotation_euler))
    return dp <= position_eps and dr <= rotation_eps


def audit_pairwise(collection=None):
    objs = [o for o in (collection.objects if collection else bpy.context.scene.objects)
            if o.type == 'MESH' and not o.hide_get()]
    overlaps=[]; duplicates=[]
    for i,a in enumerate(objs):
        for b in objs[i+1:]:
            if near_duplicate(a,b): duplicates.append((a.name,b.name))
            elif aabb_overlap(a,b): overlaps.append((a.name,b.name))
    return {'overlap_candidates': overlaps, 'near_duplicates': duplicates}

if __name__ == '__main__':
    result=audit_pairwise()
    print('BLENDER_FORGE_SPATIAL_AUDIT')
    for k,v in result.items():
        print(k, len(v))
        for item in v[:100]: print(' ', item)
