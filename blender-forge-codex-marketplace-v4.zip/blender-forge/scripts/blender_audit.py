"""Run inside Blender to print a compact scene audit for Blender Forge QA."""
import bpy

print("=== BLENDER FORGE AUDIT ===")
for obj in bpy.context.scene.objects:
    if obj.type != 'MESH':
        continue
    mesh = obj.data
    tris = 0
    for poly in mesh.polygons:
        tris += max(1, len(poly.vertices) - 2)
    dims = tuple(round(v, 4) for v in obj.dimensions)
    print(f"{obj.name}: verts={len(mesh.vertices)} faces={len(mesh.polygons)} tris~={tris} dims={dims} mats={len(obj.material_slots)}")
    if any(abs(s - 1.0) > 1e-4 for s in obj.scale):
        print("  WARN unapplied/non-unit scale:", tuple(round(v, 4) for v in obj.scale))
    if len(mesh.uv_layers) == 0:
        print("  WARN no UV map")
print("=== END AUDIT ===")
